from django import forms
from .models import scheduleModel, routineModel, commentModel
class MeasurementsForm(forms.ModelForm):
    M_BMI = forms.IntegerField()
    M_Height = forms.IntegerField()
    M_Weight = forms.IntegerField()

    class Meta:
        from .models import Measurements
        model = Measurements
        fields = ("M_BMI", "M_Height", "M_Weight")

class NutritionForm(forms.ModelForm):
    calories = forms.IntegerField()
    date = forms.IntegerField()

    class Meta:
        from .models import Nutritions
        model = Nutritions
        fields = ("calories", "date")

class ScheduleForm(forms.ModelForm):
    month = forms.CharField()
    week = forms.CharField()
    CHOICES=[
         ('Legs','Legs'),
         ('Arms','Arms'),
         ('Core','Core'),
         ('Abs','Abs'),
         ]
    workout = forms.ChoiceField(choices = CHOICES, widget = forms.RadioSelect())
    class Meta:
        model = scheduleModel
        fields = ('month', 'week', 'workout',)

class CommentForm(forms.ModelForm):
    email = forms.CharField()
    comment = forms.CharField()
    class Meta:
        model = commentModel
        fields = ('email', 'comment',)



class RoutineForm(forms.ModelForm):
    CHOICES2=[
         ('January','January'),
         ('February','February'),
         ('March','March'),
         ('April','April'),
         ('May','May'),
         ('June','June'),
         ('July','July'),
         ('August','August'),
         ('September','September'),
         ('October','October'),
         ('November','November'),
         ('December','December'),
         ]
    month = forms.ChoiceField(choices = CHOICES2, widget = forms.RadioSelect())
    week = forms.CharField()
    CHOICES=[
         ('Monday','Monday'),
         ('Tuesday','Tuesday'),
         ('Wednesday','Wednesday'),
         ('Thursday','Thursday'),
         ('Friday','Friday'),
         ('Saturday','Saturday'),
         ('Sunday','Sunday'),
         ]
    workout = forms.ChoiceField(choices = CHOICES, widget = forms.RadioSelect())
    class Meta:
        model = routineModel
        fields = ('month', 'week', 'workout',)
