from django.shortcuts import render, redirect
from accounts.forms import RegistrationForm, EditProfileForm, MeasurementForm, WorkoutForm
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserChangeForm
from django.views.generic import TemplateView



# Create your views here.
def home(request):
    numbers = [1,2,3,4,5]
    name = "YK"

    args = {'name': name, 'numbers':numbers}

    return render(request, 'accounts/home.html', args)

def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid:
            form.save()
            return redirect('/account')
    else:
        form = RegistrationForm()
        args = {'form':form}
        return render(request, 'accounts/reg_form.html', args)

def view_profile(request):
    args ={'user': request.user}
    return render (request, 'accounts/profile.html',args)

def edit_profile(request):
    if request.method =='POST':
        form = EditProfileForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            return redirect('/account/profile')
    else:
        form = EditProfileForm(instance=request.user)
        args ={'form':form}
        return render(request, 'accounts/edit_profile.html', args)

class Measurements(TemplateView):
    template_name = "info/measurements.html"
    def get (self, request):
        form = MeasurementForm()
        return render(request, "info/measurements.html", {'form':form})
    def post(self, request):
        form = MeasurementForm(request.POST)
        if form.is_valid():
            text = form.clean_data['post']
        args = {'form':forms}
        return render(request, "info/measurements.html", args)

class workoutTrack(TemplateView):
    template_name = "info/workoutTrack.html"
    def get (self, request):
        form = WorkoutForm()
        return render(request, "info/workoutTrack.html", {'form':form})
    def post(self, request):
        form = WorkoutForm(request.POST)
        if form.is_valid():
            text = form.clean_data['post']
        args = {'form':forms}
        return render(request, "info/workoutTrack.html", args)
