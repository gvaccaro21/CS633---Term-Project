from django.apps import AppConfig


class SgConfig(AppConfig):
    name = 'sg'
