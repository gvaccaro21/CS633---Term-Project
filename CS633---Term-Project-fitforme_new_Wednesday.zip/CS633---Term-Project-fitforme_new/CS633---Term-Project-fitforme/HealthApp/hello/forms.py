from django import forms
from .models import scheduleModel, routineModel
class MeasurementsForm(forms.ModelForm):
    M_BMI = forms.IntegerField()
    M_Height = forms.IntegerField()
    M_Weight = forms.IntegerField()

    class Meta:
        from .models import Measurements
        model = Measurements
        fields = ("M_BMI", "M_Height", "M_Weight")

class NutritionForm(forms.ModelForm):
    calories = forms.IntegerField()
    date = forms.IntegerField()

    class Meta:
        from .models import Nutritions
        model = Nutritions
        fields = ("calories", "date")

class ScheduleForm(forms.ModelForm):
    month = forms.CharField()
    week = forms.CharField()
    CHOICES=[
         ('test0','UpperBody'),
         ('test1','LowerBody'),
         ('test2','UpperBody'),
         ('test','LowerBody'),
         ]
    workout = forms.ChoiceField(choices = CHOICES, widget = forms.RadioSelect())
    class Meta:
        model = scheduleModel
        fields = ('month', 'week', 'workout',)

class RoutineForm(forms.ModelForm):
    CHOICES2=[
         ('test1','January'),
         ('test2','February'),
         ('test3','March'),
         ('test4','April'),
         ('test5','May'),
         ('test6','June'),
         ('test7','July'),
         ('test8','August'),
         ('test9','September'),
         ('test10','October'),
         ('test11','November'),
         ('test12','December'),
         ]
    month = forms.ChoiceField(choices = CHOICES2, widget = forms.RadioSelect())
    week = forms.CharField()
    CHOICES=[
         ('test1','Monday'),
         ('test2','Tuesday'),
         ('test3','Wednesday'),
         ('tes4','Thursday'),
         ('test5','Friday'),
         ('test6','Saturday'),
         ('test7','Sunday'),
         ]
    workout = forms.ChoiceField(choices = CHOICES, widget = forms.RadioSelect())
    class Meta:
        model = routineModel
        fields = ('month', 'week', 'workout',)
