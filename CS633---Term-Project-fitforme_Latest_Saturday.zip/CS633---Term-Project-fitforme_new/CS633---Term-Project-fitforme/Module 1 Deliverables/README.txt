Creating the initial README for Module 1.

 --GIT has been created.
 --Roles have been assigned.
 --Scope is being discussed.