from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import logout as django_logout
from django.http import HttpResponse
import logging
#import messages
from django.contrib import messages
from django.views.generic import TemplateView

from .models import Greeting, Measurements, Nutritions, scheduleModel, routineModel, commentModel
from .forms import ScheduleForm, RoutineForm, CommentForm

from django.contrib.auth.models import User

logger = logging.getLogger(__name__)

# Create your views here.
def register(request):
    # return the register page
    if request.method =="POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            args = {'form': form}
            form.save()
            return render(request, 'welcome.html', args)
        else:
            form = UserCreationForm()
            args = {'form': form}
            messages.warning(request, "User already exists or password doesn't match criteria")
            return render(request, 'register.html', args)
    else:
        form = UserCreationForm()
        args = {'form': form}
        return render(request, 'register.html', args)

def welcome(request):
    if request.method =="POST":
        form = CommentForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.user = request.user
            args = {'form': form}
            form.save()
            messages.warning(request, "Thank you for your comment, you are important for us")
            return render(request, 'welcome.html', args)
        else:
            form = CommentForm()
            args = {'form': form}
            messages.warning(request, "Our comment box is full try again later")
            return render(request, 'welcome.html', args)
    else:
        form = CommentForm()
        args = {'form': form}
        return render(request, 'welcome.html', args)
    # return the Main site page
    #usrmeasurements = Measurements.objects.get(user_id=int(request.user.id))
    usrmeasurements = Measurements.objects.filter(user_id=int(request.user.id)).values()
    #logger.warning(">>>> INFO:"+str(usrmeasurements.M_BMI))
    args = {"usrmeasurements": usrmeasurements}
    return render(request, 'welcome.html', args)

def index(request):
    # return the Main site page
    return render(request, 'index.html')

def logout(request):
    # Log the user out of the application
    django_logout(request)
    return render(request, 'index.html')

def measure(request):
    # return the Measurements Page
    usrmeasurements = Measurements.objects.all()
    args = {"usrmeasurements": usrmeasurements}
    return render(request, 'measure.html', args)

def chart(request):
    # return the Measurements Page
    #usrmeasurements = Measurements.objects.all()
    #args = {"usrmeasurements": usrmeasurements}
    return render(request, 'chart.html')



def savemeasurements(request):
    from hello.forms import MeasurementsForm
    #logger.warning(">>>> INFO: The current user id is: "+str(request.user.id))
    if Measurements.objects.filter(user_id=int(request.user.id)).exists():
        MyMeasurements = Measurements.objects.get(user_id=int(request.user.id))
        myform = MeasurementsForm(request.POST, instance=MyMeasurements)
    else:
        myform = MeasurementsForm(request.POST)
    if myform.is_valid():
        # logger.info(">>>> INFO:"+text)
        MyMeasurements = myform.save(commit=False)
        MyMeasurements.user = request.user
        MyMeasurements.save()
    return redirect("welcome")

def nutrition(request):
    # return the Measurements Page
    usrnutrition = Nutritions.objects.all()
    args = {"usrnutrition": usrnutrition}
    return render(request, 'nutrition.html', args)

    # try:
    #     username = request.user.userprofile
    # except UserProfile.DoesNotExist:
    #     username = UserProfile(user=request.user)
    # if request.method =="POST":
    #     intBMI = request.POST.get("inputBMI", "")
    #     intHeight = request.POST.get("inputHeight", "")
    #     intWeight = request.POST.get("inputWeight", "")
    #     objMeasurments = Measurements(user = username, M_BMI = intBMI, M_Height = intHeight, M_Weight = intWeight)
    #     objMeasurments.save()
def savenutrition(request):
    from hello.forms import NutritionForm
    #logger.warning(">>>> INFO: The current user id is: "+str(request.user.id))
    usrnutrition = Nutritions.objects.all()
    args = {"usrnutrition": usrnutrition}
    if Nutritions.objects.filter(user_id=int(request.user.id)).exists():
        MyNutrition = nutrition.objects.get(user_id=int(request.user.id))
        myform = NutritionForm(request.POST, instance=MyNutrition)
    else:
        myform = NutritionForm(request.POST)
    if myform.is_valid():
        MyNutrition = myform.save(commit=False)
        MyNutrition.user = request.user
        MyNutrition.save()
        usrnutrition = Nutritions.objects.all()
        args = {"usrnutrition": usrnutrition}
        messages.warning(request, "Calories Saved for Today")
        return render(request, 'nutrition', args)
    messages.warning(request, "Calories Saved for Today")
    return render(request, 'nutrition.html', args)

def getNutrition(self, request):
    form = NutritionForm()
    #usrnutrition = Nutritions.objects.all()
    current_user = request.user
    usrnutrition = Nutritions.objects.filter(user_id=current_user.id)
    print (usrnutrition)
    return render(request, 'nutrition.html', {'form':form})

class schedule(TemplateView):
    template_name="schedule.html"
    def get(self, request):
        form = ScheduleForm()
        ####
        #schedules = scheduleModel.objects.all()
        current_user = request.user
        #userid = User.objects.get(id =current_user.id).pk
        schedules = scheduleModel.objects.filter(user_id=current_user.id)
        args={'form':form, 'schedules':schedules}
        ####

        return render(request, self.template_name, args )
    def post(self, request):
        form = ScheduleForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.user = request.user
            post.save()
            month = form.cleaned_data['month']
            week = form.cleaned_data['week']
            workout = form.cleaned_data['workout']
        args = {'form': form, 'month':month, 'week':week, 'workout':workout}
        return render(request, self.template_name, args)


class routine(TemplateView):
        template_name="routine.html"
        def get(self, request):
            form = RoutineForm()
            ####
            #routines = routineModel.objects.all()
            current_user = request.user
            routines = routineModel.objects.filter(user_id=current_user.id)
            args={'form':form, 'routines':routines}
            ####

            return render(request, self.template_name, args )
        def post(self, request):
            form = RoutineForm(request.POST)
            if form.is_valid():
                post = form.save(commit=False)
                post.user = request.user
                post.save()
                month = form.cleaned_data['month']
                week = form.cleaned_data['week']
                workout = form.cleaned_data['workout']
                messages.warning(request, "Your workout has been saved")
            args = {'form': form, 'month':month, 'week':week, 'workout':workout}
            return render(request, self.template_name, args)

class comment(TemplateView):
        template_name="comments.html"
        def get(self, request):
            form = CommentForm()
            ####
            comments = commentModel.objects.all()
            args={'form':form, 'comments':comments}
            ####

            return render(request, self.template_name, args )
        def post(self, request):
            form = CommentForm(request.POST)
            if form.is_valid():
                post = form.save(commit=False)
                post.user = request.user
                post.save()
                messages.warning(request, "Your comment has been saved")
                email = form.cleaned_data['email']
                comment = form.cleaned_data['comment']

            args = {'form': form,}
            return render(request, self.template_name, args)


def db(request):

    greeting = Greeting()
    greeting.save()
    greetings = Greeting.objects.all()

    return render(request, 'db.html', {'greetings': greetings})
