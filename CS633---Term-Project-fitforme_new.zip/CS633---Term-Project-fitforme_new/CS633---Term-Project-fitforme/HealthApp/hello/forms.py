from django import forms
from .models import scheduleModel
class MeasurementsForm(forms.ModelForm):
    M_BMI = forms.IntegerField()
    M_Height = forms.IntegerField()
    M_Weight = forms.IntegerField()

    class Meta:
        from .models import Measurements
        model = Measurements
        fields = ("M_BMI", "M_Height", "M_Weight")

class NutritionForm(forms.ModelForm):
    calories = forms.IntegerField()
    date = forms.IntegerField()

    class Meta:
        from .models import Nutritions
        model = Nutritions
        fields = ("calories", "date")

class ScheduleForm(forms.ModelForm):
    month = forms.CharField()
    week = forms.CharField()
    CHOICES=[
         ('test0','UpperBody'),
         ('test1','LowerBody'),
         ('test2','UpperBody'),
         ('test','LowerBody'),
         ]
    workout = forms.ChoiceField(choices = CHOICES, widget = forms.RadioSelect())
    class Meta:
        model = scheduleModel
        fields = ('month', 'week', 'workout',)
