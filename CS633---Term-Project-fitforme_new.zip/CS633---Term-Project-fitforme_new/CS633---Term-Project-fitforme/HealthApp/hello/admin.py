from django.contrib import admin
from hello.models import UserProfile
# Register your models here.
admin.site.register(UserProfile)
